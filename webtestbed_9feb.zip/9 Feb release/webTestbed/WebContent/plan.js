

var nodeInfoParsed = JSON.parse(nodeInfo);
//console.log(nodeInfoParsed);

var nodeNames = ['NAV2','NAV1','NAV3','NAV4','POT1','POT2','POT3','POT4','MMIC','RET1','RET2','RET3','RET4','INF1','INF2','INF3','INF4',
                 'INF5','INF6','ELE1','ELE2','LUX1','LUX2','PAS1','PAS2','ONE1','ONE2','TEC1','SIG1','SIG2','SIG3','DIE1','DIE2','TOR1',
                 'TOR2','DIE3','TOR3','PHD1','NEV1','RRE1','AVE1','Ubuntu','Ubuntu1','Ubuntu2','Ubuntu3'];


var transparams={f: '751000000', n: 256, b: '12000000', r: 2, s: 1};
			var corStatus = (function () {
				var m_nodes;
				var m_floors;
				var m_floorAlreadyClicked=false;
				//var m_fullscreen=false;
				
				function ajaxReq() {
					var req = $.ajax({
						url: 'http://128.173.221.40/status',
						dataType: "jsonp",
						timeout: 35000
					});

					req.success(function (data) {
						for (var i=0; i<m_nodes.length; i++) {
							if (data[i]==2) {
								document.getElementById(m_nodes[i]).setAttribute('diffuseColor', '0 1 0'); 
							} else if (data[i]==1) {
								document.getElementById(m_nodes[i]).setAttribute('diffuseColor', '0.4 0.4 0'); 
							}
						}
					});

					req.error(function (data, string1, string2) {
					
					});
				}
				
//////////////////////////////////// populated data and actions definition

				var thisModule = {};

				thisModule.initialize = function (nodes, floors) {
					m_nodes=nodes;
					console.log(m_nodes);
					m_floors=floors;
					ajaxReq();
					
					for (var i=0; i<m_nodes.length; i++) {
						var nodeName = m_nodes[i];
						console.log(nodeName);
						var parentNode = document.getElementById(m_nodes[i]).parentNode.parentNode;
						parentNode.setAttribute('onmouseover', "oTooltip.show('<b>" + nodeName + "</b>" + "  |  Port: " + (Number(i)+7001) + "<br>Internal IP: 192.168.111." + lastDigitsIP + "', '" + m_nodes[i] + "');");
						parentNode.setAttribute('onmouseout', "oTooltip.hide('" + m_nodes[i] + "');");
						parentNode.setAttribute('onclick', "corStatus.showSpectrum(" + lastDigitsIP + ");");
					}

					for (var i=0; i<m_floors.length; i++) {	
						var parentNode = document.getElementById(m_floors[i]).parentNode.parentNode;
						parentNode.setAttribute('onmouseover', "corStatus.floorFocus(" + i + ");");
						parentNode.setAttribute('onmouseout', "corStatus.floorUnFocus(" + i + ");");
						parentNode.setAttribute('onclick', "corStatus.floorClick(" + i + ");");
					}
					document.getElementById('specGroup').setAttribute('onclick', "corStatus.showFloors();");

				}

				//onmouseover
				thisModule.floorFocus = function(floorNum) {
					document.getElementById(m_floors[floorNum]).setAttribute('emissiveColor', '0.1 0.1 0.1');
					document.getElementById(m_floors[floorNum]).setAttribute('transparency', '0');
					document.getElementById('x3dEl').style.cursor = 'pointer';
				}


				//onmouseout
				thisModule.floorUnFocus = function(floorNum) {
					document.getElementById(m_floors[floorNum]).setAttribute('emissiveColor', '0 0 0');
					document.getElementById(m_floors[floorNum]).setAttribute('transparency', '0.2');
					document.getElementById('x3dEl').style.cursor = 'default';		
				}

				thisModule.goFullscreen = function(){
					var element = document.body;
					//m_fullscreen=!m_fullscreen;
					//if (m_fullscreen) {
						if (element.requestFullScreen) {
							element.requestFullScreen();
						} else if (element.mozRequestFullScreen) {
							element.mozRequestFullScreen();
						} else if (element.webkitRequestFullScreen) {
							element.webkitRequestFullScreen();
						}
					/*} else {
						if (element.exitFullscreen) {
							element.exitFullscreen();
						} else if (element.mozCancelFullscreen) {
							element.mozCancelFullscreen();
						} else if (element.webkitExitFullscreen) {
							element.webkitExitFullscreen();
						}
					}*/
				}

				//click
				thisModule.floorClick = function(floorNum) {
					if(m_floorAlreadyClicked) {
						for (var i=0; i<m_floors.length; i++) {	
							if (i!=floorNum) {
								document.getElementById(m_floors[i]).parentNode.parentNode.parentNode.parentNode.setAttribute('render', 'true');
							}
						}
						m_floorAlreadyClicked=false;
					} else {
						for (var i=0; i<m_floors.length; i++) {	
							if (i!=floorNum) {
								document.getElementById(m_floors[i]).parentNode.parentNode.parentNode.parentNode.setAttribute('render', 'false');
							}
						}
						m_floorAlreadyClicked=true;
					}

				}

				thisModule.showSpectrum = function(lastDigitsIP) {
					/*document.getElementById('floorsGroup').setAttribute('render', 'false');
					document.getElementById('specGroup').setAttribute('render', 'true');
					spectrum.initialize(lastDigitsIP, 10, 'specGrid', 'specGridColor', 'heatmapArea', thisModule.showFloors, thisModule.showStatus, transparams);
					$('#waterfall_dialog').dialog('option', 'title', 'Real-time spectrum sensing at node 192.168.1.' + lastDigitsIP);
					$('#graph_dialog').dialog('option', 'title', 'Real-time spectrum sensing at node 192.168.1.' + lastDigitsIP);
					*/
					//oTooltip.show(abcd);
					
					//document.location.href = "/src/net.commotionwireless.olsrinfo.JsonInfo";
					//document.location.href = "/fandango1/Test1";
					
					//window.alert(document.location.href = "/fandango1/Test1");

					//var nodeInfoParsed = JSON.parse(nodeInfo);
					var iP = nodeInfoParsed[1];
					
					window.alert(iP);
					
					
					
					
					
					
					
				}

				thisModule.showFloors = function(lastDigitsIP) {
					document.getElementById('floorsGroup').setAttribute('render', 'true');
					document.getElementById('specGroup').setAttribute('render', 'false');
					spectrum.disconnect();
				}

				thisModule.showStatus = function(htmlStr) {
					$('#statusBox').html(htmlStr);
					$('#statusBox').fadeIn(400).delay(3000).fadeOut(400);
				}

				return thisModule;
			}());
			
			
////////////////////////// window on load			
			

			window.onload=function(){

				function jQueryStuff() {
					//var width = $(window).width()*0.25;
					$( "#waterfall_dialog" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 1000
						},
						position: { my: "right top", at: "right top", of: window },
						width: $(window).width()*0.7-14,
						height: $(window).height()/2,
						resizeStop: function(event, ui) {
					        //alert("Width: " + $(this).innerWidth() + ", height: " + $(this).outerHeight());   
					        //spectrum.redrawHeatmap($(this).innerWidth(), $(this).innerHeight());     
					    }
					    //resize will go faster
					});

					
					$( "#waterfall_button" ).click(function() {
						$( "#waterfall_dialog" ).dialog( "open" );
						//spectrum.redrawHeatmap();
					});



					$( "#graph_dialog" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 1000
						},
						position: { my: "right bottom", at: "right bottom-49", of: window },
						width: $(window).width()*0.7-14,
						height: $(window).height()/2-49,
						resizeStop: function(event, ui) {
					        //alert("Width: " + $(this).innerWidth() + ", height: " + $(this).outerHeight());   
					        //spectrum.redrawHeatmap($(this).innerWidth(), $(this).innerHeight());     
					    }
					    //resize will go faster
					});
					$('#graph_dialog').dialog({dialogClass:'semiTransparentWind'});

					
					$( "#graph_button" ).click(function() {
						$( "#graph_dialog" ).dialog( "open" );
						spectrum.fit();
						$('#transmit_button > :first-child').attr( "src",  "transmitPartialOn.gif");
						//spectrum.redrawHeatmap();
					});


					$( "#users_button" ).click(function() {
						spectrum.displayUsers();
					});



					$( "#rand_button" ).click(function() {
						spectrum.rand=!spectrum.rand;
						if (spectrum.rand) {
							$('#rand_button > :first-child').attr( "src",  "RandOn.gif");
						} else {
							$('#rand_button > :first-child').attr( "src",  "RandOff.gif");
						}
					});
					var gameon=false;
					$( "#game_button" ).click(function() {
						$( "#transmit_button" ).toggle();
						$( "#sliderHider" ).toggle();
						$( "#scoreArea" ).toggle();
						gameon=!gameon;
						if (gameon) {
							$('#game_button > :first-child').attr( "src",  "icons/GameOn.png");

						} else {
							$('#game_button > :first-child').attr( "src",  "icons/GameOff.png");
						}
					});

					var settings=true;
					$( "#settings_button" ).click(function() {
						$( "#settingsDiv" ).toggle();
						settings=!settings;
						if (settings) {
							$('#settings_button > :first-child').attr( "src",  "icons/settings.png");
							//send to server
							transparams.f=Number(document.getElementById('f').value)*1000000;
							transparams.n=document.getElementById('n').value;
							transparams.b=Number(document.getElementById('b').value)*1000000;
							transparams.s=document.getElementById('s').value;
							transparams.r=document.getElementById('r').value;
							spectrum.updateParams(transparams);
							document.getElementById();

						} else {
							$('#settings_button > :first-child').attr( "src",  "icons/checkmark.png");
						}
					});

					$( "#transmit_button" ).click(function() {
						spectrum.m_transmit=!spectrum.m_transmit;
						if (spectrum.m_transmit) {
							$('#transmit_button > :first-child').attr( "src",  "transmitOn.gif");
							var e = document.getElementById("mod_ctrl");
							var sel1 = e.options[e.selectedIndex].text;
							e = document.getElementById("crc_ctrl");
							var sel2 = e.options[e.selectedIndex].text;
							e = document.getElementById("ifec_ctrl");
							var sel3 = e.options[e.selectedIndex].text;
							e = document.getElementById("ofec_ctrl");
							var sel4 = e.options[e.selectedIndex].text;
							//alert(sel1 + ' ' + sel2 + ' ' + sel3 + ' ' + sel4 + ' ' + $( "#slider-delay" ).slider( "value" ) + ' ' + $( "#slider-packet" ).slider( "value" ) + ' ' + $( "#slider-power" ).slider( "value" ));

							//alert(spectrum.selectedCenter + ' ' + spectrum.selectedBandWidth);

							spectrum.setParamsCRTS({cfreq: Number(spectrum.selectedCenter) * 1000000,
								bfreq: Number(spectrum.selectedBandWidth) * 1000000,
								TXgain: $( "#slider-power" ).slider( "value" ),
								packet: $( "#slider-packet" ).slider( "value" ),
								delay: Number($( "#slider-delay" ).slider( "value" )) * 1000,
								mod: sel1,
								crc: sel2,
								ifec: sel3,
								ofec: sel4,
								nodeID: 25
							});

							document.getElementById('metrics_button').disabled=false;

						} else {
							$('#transmit_button > :first-child').attr( "src",  "transmitPartialOn.gif");
							spectrum.stopCTRS();
						}
					});


					$( "#metrics_dialog" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 1000
						},
						position: { my: "right bottom", at: "right bottom-49", of: window },
						width: $(window).width()*0.7-14,
						height: $(window).height()/2-49,
						resizeStop: function(event, ui) {
					        //alert("Width: " + $(this).innerWidth() + ", height: " + $(this).outerHeight());   
					        //spectrum.redrawHeatmap($(this).innerWidth(), $(this).innerHeight());     
					    }
					    //resize will go faster
					});
					$('#metrics_dialog').dialog({dialogClass:'semiTransparentWind'});

					$( "#metrics_button" ).click(function() {
						spectrum.getMetrics();
						$( "#metrics_dialog" ).dialog( "open" );
					});

					//slider
					$( "#slider-power" ).slider({
						orientation: "vertical",
						range: "min",
						min: -15,
						max: 20,
						value: 2.5,
						slide: function( event, ui ) {
							$( "#amount-power" ).html( ui.value );
							spectrum.m_power=ui.value;
							var size=28.571+(ui.value)*0.5714;
							$('#icon-power').width(size).height(1.5*size);
						}
					});
					$( "#amount-power" ).val( $( "#slider-power" ).slider( "value" ) );

					$( "#slider-packet" ).slider({
						orientation: "vertical",
						range: "min",
						min: 1,
						step: 1,
						max: 100,
						value: 25,
						slide: function( event, ui ) {
							$( "#amount-packet" ).html( ui.value );
							//spectrum.m_power=ui.value;
							var size=20+(ui.value)*0.2;
							$('#icon-packet').width(1.2*size).height(1.2*size);
						}
					});
					$( "#amount-packet" ).val( $( "#slider-packet" ).slider( "value" ) );

					$( "#slider-delay" ).slider({
						orientation: "vertical",
						range: "min",
						min: 100,
						max: 2000,
						value: 1000,
						slide: function( event, ui ) {
							$( "#amount-delay" ).html( ui.value );
							spectrum.m_power=ui.value;
							var size=19+(ui.value)*0.01;
							$('#icon-delay').width(size).height(1.5*size);
						}
					});
					$( "#amount-delay" ).val( $( "#slider-delay" ).slider( "value" ) );
//******************************************************************************************************
//spectrum.redrawHeatmap();
//******************************************************************************************************


					var width = $(window).width()*0.3;
				    var height = $(window).height()-49;
					$( "#help_dialog" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 1000
						},
						position: { my: "left top", at: "left top", of: window },
						width: width,
						height: height
					});
					$('#help_dialog').dialog({dialogClass:'semiTransparentWind'});
					

					$( "#waterfall_dialog" ).dialog({
						autoOpen: false,
						show: {
							effect: "blind",
							duration: 500
						},
						hide: {
							effect: "explode",
							duration: 1000
						},
						position: { my: "right top", at: "right top", of: window },
						width: $(window).width()*0.7-14,
						height: $(window).height()/2,
						resizeStop: function(event, ui) {
					        //alert("Width: " + $(this).innerWidth() + ", height: " + $(this).outerHeight());   
					        //spectrum.redrawHeatmap($(this).innerWidth(), $(this).innerHeight());     
					    }
					    //resize will go faster
					});

					
					$( "#waterfall_button" ).click(function() {
						$( "#waterfall_dialog" ).dialog( "open" );
						//spectrum.redrawHeatmap();
					});



					$( "#help_button" ).click(function() {
						$( "#help_dialog" ).dialog( "open" );
					});


					var coverLayer = $('<div>').appendTo("body").css({ "width" : "100%", "height" : "100%", "z-index" : "2", "background-color" : "rgba(0, 0, 0, 0.5)", "position" : "absolute" }).hide();
					$(".ui-dialog").on( "resizestart dragstart" , function( event, ui ) { 
					    coverLayer.show();
					    // here you can add some code that will pause webgl while user works with ui, so resizing and moving will be faster and smoother
					});

					$(".ui-dialog").on( "resizestop dragstop" , function( event, ui ) { 
					    coverLayer.hide();
					    // here you unpause webgl
					});

					function pulseIn(control) {
					    control.animate({
					        backgroundColor: "rgba(255,0,0,0.9)"
					    }, 1000, 'swing', function () {
					        pulseOut(control);
					    });
					}

					function pulseOut(control) {
					    control.animate({
					        backgroundColor: "rgba(50,50,50,0.5)"
					    }, 1000, 'swing', function () {
					            pulseIn(control);
					    });
					}
					var help_button='#help_button';
					$(help_button).each(function(){
					    pulseIn($(this));
					});
					setTimeout(function() {
					    	$(help_button).stop();
					    	$(help_button).css('background-color', 'rgba(50,50,50,0.5)');
					    }, 10000);
				};


				if (window.WebGLRenderingContext){
					var nodes=[];
					var floors=[];
					for (var i=0; i<46; i++) {
						nodes[i] = nodeNames[i];
					}
					//console.log(nodes);
					for (var i=0; i<7; i++) {  // add 7 floors : change from 4 to 7
						floors[i] = 'floor' + (i+1) + 'mat';
					}
					corStatus.initialize(nodes, floors);  ////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!initialize module
					oTooltip.init();

					jQueryStuff();
				} else {
					document.write('<div id="x3dEl"><img height="100%" width="100%" src="noWebGL.jpg"></div>');
				}
			};
