
//AJAX

$("document").ready(function () {
	
	$("#myForm").submit( function(ev){
		
		document.getElementById("status").innerHTML = "Experiment started....waiting for result";
        $.get('ExperimentS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("status").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	$("#stop").click( function(ev){
		
		document.getElementById("status").innerHTML = "Stopping Experiment....waiting for result";
        $.get('StopExperimentS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("status").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	$("#syncro").click( function(ev){
		
		document.getElementById("statusSyncro").innerHTML = "Synchronization started....waiting for result";
        $.get('ClockconfigS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("statusSyncro").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	$("#config").click( function(ev){
		
		document.getElementById("statusConfig").innerHTML = "Configuration started....waiting for result";
        $.get('WconfigS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("statusConfig").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	$("#ping").click( function(ev){
		
		document.getElementById("statusPing").innerHTML = "Execution started....waiting for result";
        $.get('PingNodeS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("statusPing").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	
	$("#setup").click( function(ev){
		
		document.getElementById("status").innerHTML = "Setup started....waiting for result";
        $.get('SetupS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("status").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	
	
	$("#sTestbed").click( function(ev){
		
		document.getElementById("status").innerHTML = "Starting Testbed....waiting for result";
        $.get('TestbedS',$("#myForm").serialize(), function(responseText) { 
        	document.getElementById("status").innerHTML = responseText;
	        	
	    });
	    ev.preventDefault();
	    //return false;
	    
	});
	

});