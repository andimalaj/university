package com.servlets.pkg;


import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jcraft.jsch.JSchException;
import com.utilities.pkg.IperfJsch;

/**
 * Servlet implementation class Experiment
 */

public class ExperimentS extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExperimentS() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//String modeId = request.getParameter("modeId");
		String time = request.getParameter("time");
		String load = request.getParameter("load");
		String recur = request.getParameter("recur");


		String hidden = request.getParameter("myInput");
		String output = "";
		

			
		Gson gson = new Gson();		
		Type type = new TypeToken<Map<String, ArrayList<String>>>(){}.getType();
		Map<String,ArrayList<String>> nodeM = gson.fromJson(hidden, type);
		IperfJsch experiment = new IperfJsch();		
		output = experiment.startExperiment(nodeM,time,load, recur);
	
        response.setContentType("text/html");  
        response.setCharacterEncoding("UTF-8"); 
        response.getWriter().write(output);
        
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		//doGet(request, response);

		
	}

}
