package com.servlets.pkg;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.utilities.pkg.IperfJsch;
import com.utilities.pkg.Setup;

/**
 * Servlet implementation class SetupS
 */
public class SetupS extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetupS() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String hidden = request.getParameter("myInput2");
		String output = "";
		

			
		Gson gson = new Gson();		
		Type type = new TypeToken<Map<String, ArrayList<String>>>(){}.getType();
		Map<String,ArrayList<String>> nodeM = gson.fromJson(hidden, type);
		Setup experiment = new Setup();		
		output = experiment.startSetup(nodeM);
	
        response.setContentType("text/html");  
        response.setCharacterEncoding("UTF-8"); 
        response.getWriter().write(output);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
