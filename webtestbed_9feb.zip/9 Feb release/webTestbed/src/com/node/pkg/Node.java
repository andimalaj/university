package com.node.pkg;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;





import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.JSONArray;

import com.google.gson.Gson;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.utilities.pkg.ReadDB;






public class Node {

	
	
	private String internalIp;
	private String status;
	private String name;
	private	String building;
	private String plane;
	private String ethIp;
	
	
	public Node() {
		
	}
	
	
	
	public Node(String internalIp, String status, String name, String building, String plane, String ethIp) {
		// TODO Auto-generated constructor stub
		this.setInternalIp(internalIp);
		this.setStatus(status);
		this.setName(name);
		this.setBuilding(building);
		this.setPlane(plane);
		this.setEthIp(ethIp);
		
		
	}
	
	
	public List<Node> populateNodes() throws IOException, SQLException{
		
		
		ReadDB db = new ReadDB();

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String connStr = "jdbc:mysql://"+db.url+":3306/"+db.dbName;
		
		
		Properties connProps = new Properties();
		connProps.put("user", db.username);
		connProps.put("password", db.password);
		connProps.put("autoReconnect", "true");
		Connection conn = DriverManager.getConnection(connStr, connProps);
		
		Statement stmt = conn.createStatement();
		//ResultSet rs = stmt.executeQuery("SELECT ipfinal,building,plane FROM PositionGW;");
		ResultSet rs = stmt.executeQuery("select p.ipfinal,g.state,g.nick,p.building, p.plane,g.IP "
				+ "from PositionNodes as p inner join Gw g on p.gwid = g.gwID;");
		
		List<Node> results = new ArrayList<Node>();
		 while(rs.next()) {
		     results.add(new Node(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
		     //System.out.println(rs.getString(1)+ rs.getString(2)+ rs.getString(3) + rs.getString(4) + rs.getString(5)+ rs.getString(6));
		 }
	 
		 rs.close();
		 stmt.close();
		 conn.close();
		 
		 
		return results;
		
		
		
	}
	
	
	
	//method used in planimetry
	public String nodeJson() throws IOException, SQLException{ 
		
		List<Node> nodes = populateNodes();
		Map<String,ArrayList<String>> nodeM = new HashMap<String,ArrayList<String>>();
		
		List<String> nickIp= new ArrayList<String>();
		
		for (int i = 0; i < nodes.size(); i++) {
			//System.out.println((nodeL.get(i)).getBuilding());
			nickIp.add((nodes.get(i)).getName());
		}
		

		
		for (int j = 0; j < nickIp.size(); j++) {
			
			List<String> ipAl= new ArrayList<String>();
		
			for (int i = 0; i < nodes.size(); i++) {
				
				if (nickIp.get(j).equals(nodes.get(i).getName())){
				
					ipAl.add((nodes.get(i)).getEthIp());
					ipAl.add((nodes.get(i)).getInternalIp());
					ipAl.add((nodes.get(i)).getStatus());
				}
			}
			nodeM.put((String)nickIp.get(j), (ArrayList<String>) ipAl);
		}
		
		
		Gson gson = new Gson();
        String nodeJson = gson.toJson(nodeM);
        //System.out.println(nodeJson);
	
        return nodeJson;
		
	
	}
	

	
	public String pingNode(){
		
		boolean reachable = false;
		String a = "State of Nodes updated correctly!";
		
		long startT = System.currentTimeMillis();
		
		ReadDB db = null;
		try {
			db = new ReadDB();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String connStr = "jdbc:mysql://"+db.url+":3306/"+db.dbName;
		
		Properties connProps = new Properties();
		connProps.put("user", db.username);
		connProps.put("password", db.password);
		connProps.put("autoReconnect", "true");
		
		try {
		 
		Connection conn = DriverManager.getConnection(connStr, connProps);
		Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = stmt.executeQuery("SELECT IP, gwID FROM Gw;");
		
		String sql = "update Gw set state = ? where gwID = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);

		while(rs.next()) {
		     
		     //System.out.println(rs.getString(1)+ rs.getString(2)+ rs.getString(3) + rs.getString(4) + rs.getString(5));
			 
 
			try {
				reachable = (java.lang.Runtime.getRuntime().exec("ping -c 1 " + rs.getString(1)).waitFor()==0);
				
				//System.out.println(reachable);
				
				if (reachable == true){
					pstmt.setString(1,"ACTIVE");
					pstmt.setString(2,rs.getString(2));
					pstmt.executeUpdate();
				}
					
				else{
					pstmt.setString(1,"INACTIVE");
					pstmt.setString(2,rs.getString(2));
					pstmt.executeUpdate();
				}
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				a = e.toString();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				a = e.toString();
			}
		
		}
		
		rs.close();
		stmt.close();
		conn.close();
		
		long stopT = System.currentTimeMillis();
		
		a = a + " in " + (stopT-startT)/60000 + " min" ;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			a = e.toString();
		}
		
		return a;
		
	}
	
	
	public String buildPlane() throws IOException, SQLException{ 
		
		Node nodeV = new Node();
		List<Node> nodeL = nodeV.populateNodes(); // azione ricorrente da esaminare; si puo chiamare una volta nel jsp
		Map<String,ArrayList<String>> nodeM = new HashMap<String,ArrayList<String>>();
		
		List<String> buildAl= new ArrayList<String>();
		
		for (int i = 0; i < nodeL.size(); i++) {
			//System.out.println((nodeL.get(i)).getBuilding());
			buildAl.add((nodeL.get(i)).getBuilding());
		}
		
		Set set = new HashSet(buildAl);
		ArrayList uniquenodeL = new ArrayList(set);
		//System.out.println("----" +uniqueList);
		
		
		//System.out.println(bildM);
		
		for (int j = 0; j < uniquenodeL.size(); j++) {
			
			List<String> planeAl= new ArrayList<String>();
		
			for (int i = 0; i < nodeL.size(); i++) {
				
				if (uniquenodeL.get(j).equals(nodeL.get(i).getBuilding()))
				
					planeAl.add((nodeL.get(i)).getPlane());
			}
			Set setP = new HashSet(planeAl);
			ArrayList uniquenodeP = new ArrayList(setP);
			nodeM.put((String)uniquenodeL.get(j), (ArrayList<String>) uniquenodeP);
		}
		
		Gson gson = new Gson();
        String nodeJson = gson.toJson(nodeM);
        
        //System.out.println(nodeJson);
	
        return nodeJson;
	
	}
	
	public String planeNode() throws IOException, SQLException{ 
		
		Node nodeV = new Node();
		List<Node> nodeL = nodeV.populateNodes(); // azione ricorrente da esaminare; si puo chiamare una volta nel jsp
		Map<String,ArrayList<String>> nodeM = new HashMap<String,ArrayList<String>>();
		
		List<String> planeAl= new ArrayList<String>();
		
		for (int i = 0; i < nodeL.size(); i++) {
			//System.out.println((nodeL.get(i)).getBuilding());
			planeAl.add((nodeL.get(i)).getPlane());
		}
		
		Set set = new HashSet(planeAl);
		ArrayList uniquenodeL = new ArrayList(set);
		//System.out.println("----" +uniqueList);
		
		
		//System.out.println(bildM);
		
		for (int j = 0; j < uniquenodeL.size(); j++) {
			
			List<String> ipAl= new ArrayList<String>();
		
			for (int i = 0; i < nodeL.size(); i++) {
				
				if (uniquenodeL.get(j).equals(nodeL.get(i).getPlane()))
				
					ipAl.add((nodeL.get(i)).getName());
			}
			nodeM.put((String)uniquenodeL.get(j), (ArrayList<String>) ipAl);
		}
		//System.out.println(nodeM);
		
		Gson gson = new Gson();
        String nodeJson = gson.toJson(nodeM);
        
        //System.out.println(nodeJson);
	
        return nodeJson;
	
	
	}
	
	public String nickIp() throws IOException, SQLException{ 
		
		Node nodeV = new Node();
		List<Node> nodeL = nodeV.populateNodes(); // azione ricorrente da esaminare; si puo chiamare una volta nel jsp
		Map<String,String> nodeM = new HashMap<String,String>();
		
		
		for (int j = 0; j < nodeL.size(); j++) {
			
			nodeM.put(nodeL.get(j).getName(),nodeL.get(j).getInternalIp());
		}
		//System.out.println(nodeM);
		
		Gson gson = new Gson();
        String nodeJson = gson.toJson(nodeM);
        
        //System.out.println(nodeJson);
	
        return nodeJson;
	
	
	}
	
	public String ethIp() throws IOException, SQLException{ 
		
		Node nodeV = new Node();
		List<Node> nodeL = nodeV.populateNodes(); // azione ricorrente da esaminare; si puo chiamare una volta nel jsp
		Map<String,String> nodeM = new HashMap<String,String>();
		
		
		for (int j = 0; j < nodeL.size(); j++) {
			
			nodeM.put(nodeL.get(j).getName(),nodeL.get(j).getEthIp());
		}
		//System.out.println(nodeM);
		
		Gson gson = new Gson();
        String nodeJson = gson.toJson(nodeM);
        
        //System.out.println(nodeJson);
	
        return nodeJson;
	
	
	}
	
	public String getEthIpfromIp(String ipWifi){
		
		String ethIp = null;
		
		Node nodeV = new Node();
		List<Node> nodeL = null;
		try {
			nodeL = nodeV.populateNodes();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // azione ricorrente da esaminare; si puo chiamare una volta nel jsp
		Map<String,String> nodeM = new HashMap<String,String>();
		
		for (int j = 0; j < nodeL.size(); j++) {
			
			if (nodeL.get(j).getInternalIp().equals(ipWifi)){
				
				ethIp = nodeL.get(j).getEthIp();
				break;
				
			}
					
					
		}
		
		
		return ethIp;
		
	}
	
	
	
	
	
	public String getBuilding() {
		return building;
	}



	public void setBuilding(String building) {
		this.building = building;
	}



	public String getPlane() {
		return plane;
	}



	public void setPlane(String plane) {
		this.plane = plane;
	}



	public String getInternalIp() {
		return internalIp;
	}



	public void setInternalIp(String internalIp) {
		this.internalIp = internalIp;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEthIp() {
		return ethIp;
	}



	public void setEthIp(String ethIp) {
		this.ethIp = ethIp;
	}




	
	

}
