package com.utilities.pkg;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class Setup {

	public Setup() {
		// TODO Auto-generated constructor stub
	}
	
	public String startSetup(Map<String,ArrayList<String>> hashSlet) {
		
		Map<String,ArrayList<String>> hashNodes = hashSlet;
				
		String output = "Setup finished successfully!";

		
  	   String commandC = "/root/COGNET_TESTBED/startCOGNET.sh";
		
 	   Properties props = new Properties();
 	   InputStream input = null;		   
 	   input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
 	   try {
 		props.load(input);
 	   }catch (IOException e1) {
 		// TODO Auto-generated catch block
 		output = e1.toString();
 	   }

 	   String user = props.getProperty("node_login");
 	   String password = props.getProperty("node_password");
		
		 try{
		      JSch jsch=new JSch();  
		 	      
		      
		      
		      for (String hostS : hashNodes.keySet()) {
		    	  ArrayList<String> allClients = hashNodes.get(hostS);
		    	  
			      java.util.Properties config = new java.util.Properties(); 
			      config.put("StrictHostKeyChecking", "no");
		    	
		      		 
			      Session sessionS=jsch.getSession(user, hostS, 22); 
			      sessionS.setConfig(config);		      
			      sessionS.setPassword(password);		      		     		      
			      sessionS.connect();
			      
			      Channel channelS=sessionS.openChannel("exec");
			      ((ChannelExec)channelS).setCommand(commandC);
			      channelS.connect();
			      
			      Thread.sleep(5000);
			      
			      
	    	  	  Channel channelSS=sessionS.openChannel("exec");
			      ((ChannelExec)channelSS).setCommand("echo 127.0.0.1 >> /root/MANAGER/IP_FILES_WEBAPP/FILE_CLIENT_IP.TXT");
			      channelSS.connect();
			      
			      Thread.sleep(5000);
			    
			      
			      for (String hostC : allClients) {
			        	
			    	  	Channel channelSSS=sessionS.openChannel("exec");
					    ((ChannelExec)channelSSS).setCommand("echo " + hostC + " >> /root/MANAGER/IP_FILES_WEBAPP/FILE_CLIENT_IP.TXT");
					    channelSSS.connect();
					    
					    
					    Thread.sleep(5000);
					    
			      }
			      

			      
			      for (String hostC : allClients) {
			        	
			            Session sessionC=jsch.getSession(user, hostC, 22); 
			            sessionC.setConfig(config);		      
			            sessionC.setPassword(password);		      		     		      
			            sessionC.connect();
				      		 
					    Channel channelC=sessionC.openChannel("exec");
					    ((ChannelExec)channelC).setCommand(commandC);
					    channelC.connect();
					    
			      }
			      
			      
		      
			    }
		 }
	    catch(Exception e){
		      //System.out.println(e);
		      output = "Error on nodes :" + hashNodes + " " + e.getStackTrace();
	    }
		
		
	    return output;

    }

}
