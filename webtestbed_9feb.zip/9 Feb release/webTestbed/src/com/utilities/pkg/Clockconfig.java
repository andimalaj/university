package com.utilities.pkg;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class Clockconfig {

	public Clockconfig() {
		// TODO Auto-generated constructor stub
	}
	
	public String startSynchronisation(Map<String,ArrayList<String>> hashSlet) {
		
		   Map<String,ArrayList<String>> hashNodes = hashSlet;
					
		   String output = null;
	 
	 	   Properties props = new Properties();
	 	   InputStream input = null;		   
	 	   input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
	 	   try {
	 		props.load(input);
	 	   }catch (IOException e1) {
	 		// TODO Auto-generated catch block
	 		output = e1.toString();
	 	   }
	
	 	   String user = props.getProperty("node_login");
	 	   String password = props.getProperty("node_password");
	 	   String ntpS = props.getProperty("ntp_server");
	 	   
	 	   String commandC = "ntpdate "+ ntpS;
			
		   try{
		      JSch jsch=new JSch();  
		 	      
		      
		      
		      for (String hostS : hashNodes.keySet()) {
		    	  ArrayList<String> allClients = hashNodes.get(hostS);
		    	  
			      java.util.Properties config = new java.util.Properties(); 
			      config.put("StrictHostKeyChecking", "no");
		    	
		      		 
			      Session sessionS=jsch.getSession(user, hostS, 22); 
			      sessionS.setConfig(config);		      
			      sessionS.setPassword(password);		      		     		      
			      sessionS.connect();
			      
			      Channel channelS=sessionS.openChannel("exec");
			      ((ChannelExec)channelS).setCommand(commandC);
	
			      
			      for (String hostC : allClients) {
			        	
			            Session sessionC=jsch.getSession(user, hostC, 22); 
			            sessionC.setConfig(config);		      
			            sessionC.setPassword(password);		      		     		      
			            sessionC.connect();
				      		 
					    Channel channelC=sessionC.openChannel("exec");
					    ((ChannelExec)channelC).setCommand(commandC);
					    
			      }
		      
			    }
		   }
		   catch(Exception e){
			      //System.out.println(e);
			      return 	"Error on nodes :" + hashNodes + " " + e.getStackTrace();
		   }
			
			
		   return 	"Synchronisation finished successfully!";

    }

}
