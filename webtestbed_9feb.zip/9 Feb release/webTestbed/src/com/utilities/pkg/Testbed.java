package com.utilities.pkg;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class Testbed {

	public Testbed() {
		// TODO Auto-generated constructor stub
	}
	
	public String startTestbed(Map<String,ArrayList<String>> hashSlet, String port, String times) {
		
		Map<String,ArrayList<String>> hashNodes = hashSlet;
				
		String output = "Testbed started successfully!";

		
  	    String commandC = "/root/MANAGER/managerCognetAlix.out startContinue " + port + " /root/MANAGER/IP_FILES_WEBAPP/FILE_CLIENT_IP.TXT " + times ;

		
 	   Properties props = new Properties();
 	   InputStream input = null;		   
 	   input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
 	   try {
 		props.load(input);
 	   }catch (IOException e1) {
 		// TODO Auto-generated catch block
 		output = e1.toString();
 	   }

 	   String user = props.getProperty("node_login");
 	   String password = props.getProperty("node_password");
		
		 try{
		      JSch jsch=new JSch();  
		 	      
		      
		      
		      for (String hostS : hashNodes.keySet()) {
		    	  
			      java.util.Properties config = new java.util.Properties(); 
			      config.put("StrictHostKeyChecking", "no");
		    	
		      		 
			      Session sessionS=jsch.getSession(user, hostS, 22); 
			      sessionS.setConfig(config);		      
			      sessionS.setPassword(password);		      		     		      
			      sessionS.connect();
			      
			      Channel channelS=sessionS.openChannel("exec");
			      ((ChannelExec)channelS).setCommand(commandC);
			      channelS.connect();

		      
			    }
		      
		      
		 }
	    catch(Exception e){
		      //System.out.println(e);
	    	output = "Error on nodes :" + hashNodes + " " + e.getStackTrace();
	    }
		
		
	    return 	output;

    }
	

}
