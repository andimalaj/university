package com.utilities.pkg;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;



public class ReadDB {
	
	public String url;
	public String username;
	public String password;
	public String dbName;

	public ReadDB() throws IOException {
		
		   Properties props = new Properties();
		   InputStream input = null;		   
		   input = getClass().getClassLoader().getResourceAsStream("db.properties"); 	   
		   props.load(input);

		   String url = props.getProperty("jdbc_url");
		   String username = props.getProperty("jdbc_username");
		   String password = props.getProperty("jdbc_password");
		   String dbName = props.getProperty("jdbc_name");
		   
		   
		   this.url = url;
		   this.username = username;
		   this.password = password;
		   this.dbName = dbName;
		
		
		
	}

}
