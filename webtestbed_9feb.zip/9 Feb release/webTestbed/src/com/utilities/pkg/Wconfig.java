package com.utilities.pkg;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class Wconfig {

	public Wconfig() {
		// TODO Auto-generated constructor stub
	}
	
	
	public String startConfiguration(Map<String,ArrayList<String>> hashSlet,String channel,String power) {
		
		Map<String,ArrayList<String>> hashNodes = hashSlet;
				
		String output = null;
		
		/*
		ifconfig wlan0 down
		iw reg set BO
		ifconfig wlan0 up
		iwconfig wlan0 channel 13
		iwconfig wlan0 txpower 30
		 */
		
  	    String commandC = "iwconfig wlan0 channel " + Integer.parseInt(channel) + " txpower " +Integer.parseInt(power);
		
 	   Properties props = new Properties();
 	   InputStream input = null;		   
 	   input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
 	   try {
 		props.load(input);
 	   }catch (IOException e1) {
 		// TODO Auto-generated catch block
 		output = e1.toString();
 	   }

 	   String user = props.getProperty("node_login");
 	   String password = props.getProperty("node_password");
		
		 try{
		      JSch jsch=new JSch();  
		 	      
		      
		      
		      for (String hostS : hashNodes.keySet()) {
		    	  ArrayList<String> allClients = hashNodes.get(hostS);
		    	  
			      java.util.Properties config = new java.util.Properties(); 
			      config.put("StrictHostKeyChecking", "no");
		    	
		      		 
			      Session sessionS=jsch.getSession(user, hostS, 22); 
			      sessionS.setConfig(config);		      
			      sessionS.setPassword(password);		      		     		      
			      sessionS.connect();
			      
			      Channel channelS=sessionS.openChannel("exec");
			      ((ChannelExec)channelS).setCommand(commandC);
			      channelS.connect();

			      
			      for (String hostC : allClients) {
			        	
			            Session sessionC=jsch.getSession(user, hostC, 22); 
			            sessionC.setConfig(config);		      
			            sessionC.setPassword(password);		      		     		      
			            sessionC.connect();
				      		 
					    Channel channelC=sessionC.openChannel("exec");
					    ((ChannelExec)channelC).setCommand(commandC);
					    channelC.connect();
					    
			      }
		      
			    }
		 }
	    catch(Exception e){
		      //System.out.println(e);
		      return 	"Error on nodes :" + hashNodes + " " + e.getStackTrace();
	    }
		
		
	    return 	"Configuration finished successfully!";

    }
	

}
