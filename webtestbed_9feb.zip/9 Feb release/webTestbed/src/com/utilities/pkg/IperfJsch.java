package com.utilities.pkg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.node.pkg.Node;

public class IperfJsch {

	public IperfJsch() {
		// TODO Auto-generated constructor stub
	}

	public String startExperiment(Map<String,ArrayList<String>> hashSlet,String time,String load, String recur) {
		
		Map<String,ArrayList<String>> hashNodes = hashSlet;
		boolean isTime= false;
		boolean isLoad = false;
		
		if (time!=null){
			isTime = true;
			isLoad = false;
		}
		else if (load!=null){
			isTime = false;
			isLoad = true;
		}
		
		
	   String output = "Experiment finished successfully!";
		
	   Properties props = new Properties();
	   InputStream input = null;		   
	   input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
	   try {
		props.load(input);
	   }catch (IOException e1) {
		// TODO Auto-generated catch block
		output = e1.toString();
	   }

	   String user = props.getProperty("node_login");
	   String password = props.getProperty("node_password");


		
		 try{
		      JSch jsch=new JSch();  

		      for (String hostS : hashNodes.keySet()) {
		    	  ArrayList<String> allClients = hashNodes.get(hostS);
		    	  
		    	  Node node = new Node();
		    	  String hostSeth = node.getEthIpfromIp(hostS);
		    	  
		    	  
		    	  String commandS = "iperf -s";
		    	  String commandC = "";
		    	  
		    	  if (isTime == true)
		    		  commandC = "iperf -c " + hostS + " -t " + time;
		    	  else if(isLoad == true)
		    		  commandC = "iperf -c " + hostS + " -n " + load;
		    	  else 
		    		  commandC = "iperf -c " + hostS;
		    	  //System.out.println(commandC);
		    	  
			      String commandE = "kill `pgrep iperf`";
			      java.util.Properties config = new java.util.Properties(); 
			      config.put("StrictHostKeyChecking", "no");
		    	
		      		 
			      Session sessionS=jsch.getSession(user, hostSeth, 22);
			      sessionS.setConfig(config);		      
			      sessionS.setPassword(password);		      		     		      
			      sessionS.connect();
			      
			      Channel channelS=sessionS.openChannel("exec");
			      
			      //kill eventual past iperf on server
              	  //((ChannelExec)channelS).setCommand(commandE);
              	  //channelS.connect();
              	  

              	  ((ChannelExec)channelS).setCommand(commandS);
                  channelS.setInputStream(null);
                  ((ChannelExec)channelS).setErrStream(System.err);             
                  InputStream in=channelS.getInputStream();			      
			      channelS.connect();			      
			 
			      int exitStatus = -100;
			      
			      long tStart = System.currentTimeMillis();
			      long tEnd = System.currentTimeMillis();
			      
			      for(int j = 0;j < Integer.parseInt(recur); j++){
			      
				      for (String hostC : allClients) {
				    	  
				    	  	String hostCeth = node.getEthIpfromIp(hostC);
				        	
				            Session sessionC=jsch.getSession(user, hostCeth, 22); 
				            sessionC.setConfig(config);		      
				            sessionC.setPassword(password);		      		     		      
				            sessionC.connect();
					      		 
						    Channel channelC=sessionC.openChannel("exec");
						    ((ChannelExec)channelC).setCommand(commandC);
						    channelC.connect();
						    
				      }
			      }
			      
			      byte[] tmp=new byte[1024];
			      //sessionS.setTimeout(15);
			      //channelS.

			      while(true){
			    	  
			    	    tEnd = System.currentTimeMillis();
				        while(in.available()>0){
				          int i=in.read(tmp, 0, 1024);
				          if(i<0) break;
				          System.out.print(new String(tmp, 0, i));
				          //System.out.print(sessionS.getTimeout());
				        }
				        
				        
				        
				        if((tEnd- tStart)/1000 > Integer.parseInt(recur)*30){
						   // Channel channelSk=sessionS.openChannel("exec");
				        	//((ChannelExec)channelSk).setCommand(commandE);
							//channelSk.connect();
							break;
				        }

			      }
			      
		          if (channelS.isClosed()) {
	                    exitStatus = channelS.getExitStatus();
	                    break;
	                
	              }
	
 
			        
			      System.out.println(exitStatus);
			      //System.out.println("Il risultato: " + output);
			      
			      channelS.disconnect();
			      sessionS.disconnect();
		        
		      }
		    }
	    catch(Exception e){
		      //System.out.println(e);
		      output = "Error on nodes :" + hashNodes + " " + e;
	    }
		
		
	return 	output;

	}
	
	
	public String stopExperiment(Map<String,ArrayList<String>> hashSlet) {
		
		Map<String,ArrayList<String>> hashNodes = hashSlet;
		
	    String output = "Experiment stopped successfully!";
		
	    Properties props = new Properties();
	    InputStream input = null;		   
	    input = getClass().getClassLoader().getResourceAsStream("config.properties"); 	   
	    try {
		 props.load(input);
	    }
	    catch (IOException e1) {
		 output = e1.toString();
	    }
	    
	    String user = props.getProperty("node_login");
	    String password = props.getProperty("node_password");
	    
	    
 	    String commandC = "kill `pgrep iperf`";
		
	    try{
	      JSch jsch=new JSch();  
	 	      
	      
	      
	      for (String hostS : hashNodes.keySet()) {
	    	  
		      java.util.Properties config = new java.util.Properties(); 
		      config.put("StrictHostKeyChecking", "no");
		      
	    	  Node node = new Node();
	    	  String hostSeth = node.getEthIpfromIp(hostS);
	    	
	      		 
		      Session sessionS=jsch.getSession(user, hostSeth, 22); 
		      sessionS.setConfig(config);		      
		      sessionS.setPassword(password);		      		     		      
		      sessionS.connect();
		      
		      Channel channelS=sessionS.openChannel("exec");
		      ((ChannelExec)channelS).setCommand(commandC);
		      channelS.connect();
		      
	      
		    }
	    }
	    catch(Exception e){
		      //System.out.println(e);
	    	output = "Error on nodes :" + hashNodes + " " + e.getStackTrace();
	    }
	    
		
		
		return output;
	
	}

}
